import os
import shutil
import re

SFM_ROOT = r"C:\Program Files (x86)\Steam\steamapps\common\SourceFilmmaker\game"

MODEL_EXTS = {'.mdl', '.vvd', '.vtx', '.phy', '.dx90.vtx', '.sw.vtx'}
MATERIAL_EXTS = {'.vmt', '.vtf'}

def get_correct_path(file_path, root, is_model_file):
    # Пытаемся найти корень папки внутри usermod или другого игрового мода
    parts = root.split(os.sep)
    for i, part in enumerate(parts):
        if part.lower() in ['usermod', 'tf', 'workshop']:
            # Базовая папка мода
            base = os.path.join(*parts[:i+1])
            if is_model_file:
                return os.path.join(base, "models", os.path.basename(root), os.path.basename(file_path))
            else:
                return os.path.join(base, "materials", os.path.basename(root), os.path.basename(file_path))
    return None

def fix_sfm():
    print("=== АВТОМАТИЧЕСКАЯ КОРРЕКЦИЯ СТРУКТУРЫ SFM ===")
    
    for root, dirs, files in os.walk(SFM_ROOT):
        # Пропускаем системные директории
        if any(bad in root.lower() for bad in ['\\bin', '\\platform', '\\launcher']):
            continue
            
        for file in files:
            file_path = os.path.join(root, file)
            _, ext = os.path.splitext(file.lower())
            
            # 1. Если МОДЕЛЬ в MATERIALS - пытаемся перенести в MODELS
            if "\\materials" in root.lower() and ext in MODEL_EXTS:
                target = get_correct_path(file_path, root, True)
                if target:
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    shutil.move(file_path, target)
                    print(f"[ПЕРЕМЕЩЕНО]: Модель {file} -> models/")
                else:
                    os.remove(file_path)
                    print(f"[УДАЛЕНО]: Неверная модель {file}")

            # 2. Если МАТЕРИАЛ в MODELS - пытаемся перенести в MATERIALS
            elif "\\models" in root.lower() and ext in MATERIAL_EXTS:
                target = get_correct_path(file_path, root, False)
                if target:
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    shutil.move(file_path, target)
                    print(f"[ПЕРЕМЕЩЕНО]: Материал {file} -> materials/")
                else:
                    os.remove(file_path)
                    print(f"[УДАЛЕНО]: Неверный материал {file}")

    print("\n=== ГОТОВО. Структура восстановлена. ===")

if __name__ == "__main__":
    fix_sfm()