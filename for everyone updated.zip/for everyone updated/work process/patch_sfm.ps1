# ==============================================================================
# SFM Self-Calibrating Hyper-Optimizer & Asset Guard (V3 Enterprise Autotune & Logger)
# ==============================================================================
# Performs deep system calibration, dynamic memory ceiling calculations, 
# patches game binaries, optimizes and locks configs, configures Launch Options,
# and generates a detailed optimization log.
# ==============================================================================

$logPath = Join-Path $PSScriptRoot "sfm_patch_log.txt"
$logContent = @()

function Write-Log {
    param ([string]$message, [string]$level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $formattedMsg = "[$timestamp] [$level] $message"
    $global:logContent += $formattedMsg
    
    switch ($level) {
        "SUCCESS" { Write-Host $message -ForegroundColor Green }
        "WARNING" { Write-Host $message -ForegroundColor Yellow }
        "ERROR"   { Write-Host $message -ForegroundColor Red }
        default   { Write-Host $message -ForegroundColor Cyan }
    }
}

Write-Log "Initializing SFM Deep Self-Calibrating Patcher..." "INFO"

# --- STEP 1: DYNAMIC PATH DETECTION ---
$sfmPath = $null

if ($PSScriptRoot) {
    if (Test-Path (Join-Path $PSScriptRoot "sfm.exe")) {
        $sfmPath = Split-Path $PSScriptRoot -Parent
    } elseif (Test-Path (Join-Path $PSScriptRoot "SourceFilmmaker")) {
        $sfmPath = Join-Path $PSScriptRoot "SourceFilmmaker"
    }
}

if ($null -eq $sfmPath) {
    try {
        $steamPath = (Get-ItemProperty -Path "HKCU:\Software\Valve\Steam").SteamPath
        if ($steamPath -and (Test-Path $steamPath)) {
            $libFile = Join-Path $steamPath "steamapps\libraryfolders.vdf"
            if (Test-Path $libFile) {
                $libContent = Get-Content $libFile -Raw
                $matches = [regex]::Matches($libContent, '"path"\s+"([^"]+)"')
                foreach ($match in $matches) {
                    $drivePath = $match.Groups[1].Value -replace '\\\\', '\'
                    $testPath = Join-Path $drivePath "steamapps\common\SourceFilmmaker"
                    if (Test-Path $testPath) {
                        $sfmPath = $testPath
                        break
                    }
                }
            }
        }
    } catch {
        Write-Log "Steam Registry detection failed. Falling back to static scan." "WARNING"
    }
}

if ($null -eq $sfmPath) {
    $standardPaths = @(
        "C:\Program Files (x86)\Steam\steamapps\common\SourceFilmmaker",
        "C:\Program Files\Steam\steamapps\common\SourceFilmmaker",
        "D:\SteamLibrary\steamapps\common\SourceFilmmaker",
        "E:\SteamLibrary\steamapps\common\SourceFilmmaker"
    )
    foreach ($path in $standardPaths) {
        if (Test-Path $path) { $sfmPath = $path; break }
    }
}

if ($null -eq $sfmPath -or -not (Test-Path $sfmPath)) {
    Write-Log "CRITICAL: Could not find Source Filmmaker directory." "ERROR"
    Set-Content -Path $logPath -Value ($logContent -join "`r`n")
    Pause; exit
}

Write-Log "TARGET SFM PATH ACQUIRED: $sfmPath" "SUCCESS"

# --- STEP 2: SAFE ATTRIBUTE TOGGLE ---
function Disable-ReadOnly ($filePath) {
    if (Test-Path $filePath) {
        $file = Get-Item $filePath -Force
        if ($file.IsReadOnly) { $file.IsReadOnly = $false }
    }
}

function Enable-ReadOnly ($filePath) {
    if (Test-Path $filePath) {
        $file = Get-Item $filePath -Force
        $file.IsReadOnly = $true
    }
}

# --- STEP 3: HIGH-SPEED TEMP & CRASH CLEANUP ---
Write-Log "Running fast temporary file and memory dump cleanup..." "INFO"
$cleanExtensions = @("*.mdmp", "*.log", "*.tmp", "crash_*.dat")
$deletedCount = 0
foreach ($ext in $cleanExtensions) {
    $files = Get-ChildItem -Path $sfmPath -Filter $ext -Recurse -ErrorAction SilentlyContinue
    foreach ($f in $files) {
        try {
            Remove-Item $f.FullName -Force -ErrorAction SilentlyContinue
            $deletedCount++
        } catch {}
    }
}
Write-Log "Cleanup completed. Deleted $deletedCount temporary files/dumps." "SUCCESS"

# --- STEP 4: SYSTEM BINARY & DLL LARGE-ADDRESS-AWARE (x64/4GB+) PATCHING ---
function Apply-BinaryPatch ($filePath) {
    if (Test-Path $filePath) {
        Disable-ReadOnly $filePath
        try {
            [byte[]]$bytes = [System.IO.File]::ReadAllBytes($filePath)
            if ($bytes.Length -gt 64) {
                $peOffset = [System.BitConverter]::ToInt32($bytes, 0x3C)
                if ($peOffset -lt $bytes.Length - 50) {
                    $characteristicsOffset = $peOffset + 4 + 18
                    $characteristics = [System.BitConverter]::ToUInt16($bytes, $characteristicsOffset)
                    if (($characteristics -band 0x0020) -ne 0x0020) {
                        $newCharacteristics = $characteristics -bor 0x0020
                        $newBytes = [System.BitConverter]::GetBytes($newCharacteristics)
                        $bytes[$characteristicsOffset] = $newBytes[0]
                        $bytes[$characteristicsOffset + 1] = $newBytes[1]
                        [System.IO.File]::WriteAllBytes($filePath, $bytes)
                        Write-Log "Successfully patched Large Address Aware (LAA) -> $filePath" "SUCCESS"
                    } else {
                        Write-Log "Binary already supports LAA -> $filePath" "INFO"
                    }
                }
            }
        } catch {
            Write-Log "Failed to patch binary: $filePath. Error: $_" "WARNING"
        }
        finally {
            Enable-ReadOnly $filePath
        }
    }
}

Write-Log "Scanning and patching core system binaries in bin/ directory..." "INFO"
$binFiles = Get-ChildItem -Path "$sfmPath" -Include "*.exe", "*.dll" -Recurse -ErrorAction SilentlyContinue
foreach ($file in $binFiles) {
    if ($file.Name -match "engine|shader|client|server|sfm|studio|datacache|vphysics|vguimatsurface") {
        Apply-BinaryPatch $file.FullName
    }
}

# --- STEP 5: DYNAMIC SYSTEM CAPABILITIES DISCOVERY (MAX LIMIT TUNING) ---
Write-Log "Scanning hardware capability to calculate ultimate limits..." "INFO"
$osInfo = Get-WmiObject -Class Win32_OperatingSystem
$totalRamBytes = $osInfo.TotalVisibleMemorySize * 1KB
$totalRamGB = [Math]::Round($totalRamBytes / 1GB, 2)
Write-Log "Detected Physical Memory: $totalRamGB GB RAM" "INFO"

# Вычисление пределов значений в конфигах без вызова переполнения парсера Source
function Get-SafeMaxLimit {
    param (
        [string]$TypeHint
    )
    if ($TypeHint -eq "int") {
        return "16777216"
    } elseif ($TypeHint -eq "float") {
        return "999999.0"
    } elseif ($TypeHint -eq "float_min") {
         return "0.000001"
    }
    return "0"
}

$maxInt = Get-SafeMaxLimit -TypeHint "int"
$maxFloat = Get-SafeMaxLimit -TypeHint "float"
$minFloat = Get-SafeMaxLimit -TypeHint "float_min"

Write-Log "Calculated safe limits: MaxInt=$maxInt, MaxFloat=$maxFloat, MinFloat=$minFloat" "INFO"

# --- STEP 6: WRITING OPTIMIZED CONFIGURATIONS ---
$cfgDir = "$sfmPath\game\usermod\cfg"
if (-not (Test-Path $cfgDir)) { New-Item -ItemType Directory -Force -Path $cfgDir | Out-Null }

$autoexecPath = "$cfgDir\autoexec.cfg"
$configPath = "$cfgDir\config.cfg"
$videoPath = "$cfgDir\video.txt"

Disable-ReadOnly $autoexecPath
Disable-ReadOnly $configPath
Disable-ReadOnly $videoPath

# Пишем ультра-оптимизированный autoexec (с твоими лимитами и исправленными HDR + Jiggle)
$autoexecContent = @"
// ==========================================
// AUTO-GENERATED EXTREME CONFIG (DYNAMIC CAPACITY)
// ==========================================
mat_queue_mode 2
host_thread_mode 2
cl_threaded_bone_setup 1
cl_threaded_client_leaf_system 1
r_threaded_renderables 1
r_threaded_particles 1
r_threaded_shadow_clip 1
r_queued_decals 1
r_queued_ropes 1
r_queued_post_processing 1
studio_queue_mode 1
sv_parallel_sendsnapshot 1
net_queued_packet_thread 1
mem_max_heapsize 31457279
datacache_flush_interval 0
mod_forcedata 1
mod_lock_mdls_on_load 1
cl_forcepreload 1
mod_load_anims_async 1
mod_load_mesh_async 1
mod_load_vcollide_async 1
mat_managedtextures 1
mat_texture_list_all 1
r_occlusion 0
r_shadows 1
r_shadowrendertotexture 1
r_shadowmaxrendered $maxInt
r_shadow_deferred_downsample 0
r_shadow_fallow_distance $maxInt
r_projectedtexture_filter $minFloat
r_shadow_realtime_world_debug 0
mat_slopescaledepthbias_shadowmap 2.0
mat_depthbias_shadowmap 0.00001
r_dynamic 1
r_maxdlights $maxInt
r_worldlights $maxInt
r_lightaverage 1
r_lightcache_num_entities $maxInt
r_lightinterp 0
r_lightstyle -1
r_ambientboost 1
r_ambientfactor 20
r_ambientmin 1.0
r_radiosity 4
mat_picmip -10
mat_antialias 8
mat_forceaniso 16
mat_filtertextures 1
mat_filterlightmaps 1
r_lod 0
r_rootlod 0
r_staticprop_lod 0
lod_TransitionDist $maxInt
mat_bumpmap 1
mat_parallaxmap 1
mat_specular 1
mat_phong 1
mat_envmapsize 1024
mat_envmaptgasize 1024
mat_envmapcomputefn 1
cl_particle_retire_cost 0
r_particle_sim_multiplier 4
r_interactive_particle_res 1024
cl_new_impact_effects 1
r_drawflecks 1
r_drawshatter_effects 1
r_waterforceexpensive 1
r_waterforcereflectentities 1
r_waterdrawreflection 1
r_waterdrawrefraction 1
r_forcewaterleaf 1
mat_reflect_textures 1
r_cheapwaterstart $maxInt
r_cheapwaterend $maxInt
cl_phys_props_max $maxInt
r_maxmodeldecal $maxInt
r_decals $maxInt
mp_decals $maxInt
cl_detaildist $maxInt
r_propsmaxdist $maxInt
cl_detailfade 0
r_drawdetailprops 1
r_3dsky 1
r_skybox 1
mat_motion_blur_enabled 1
mat_motion_blur_strength 1.5

// === ИСПРАВЛЕННЫЕ КОМАНДЫ ФИЗИКИ JIGGLE BONES ===
cl_jiggle_bone_sanity 1
cl_jiggle_bone_invert 0

r_flex_smooth 1
cl_ragdoll_collide 1
cl_burninggibs 1
r_eyegloss 1
r_eyemove 1
r_eyesize 0
ai_expression_optimization 0
cl_interp 0
cl_interp_ratio 1
cl_cmdrate 100
cl_updaterate 100
rate 1048576
mat_reloadallmaterials
mat_reloadtextures
"@

# Пишем массивный config.cfg (с точечно поправленным HDR)
$configContent = @"
sv_cheats 1
developer 1
con_enable 1
mat_queue_mode 2
host_thread_mode 2
cl_threaded_bone_setup 1
cl_threaded_client_leaf_system 1
r_threaded_renderables 1
r_threaded_particles 1
r_threaded_shadow_clip 1
studio_queue_mode 1
datacache_flush_interval 0
mem_max_heapsize 31457279
r_norefresh 0
r_fastzreject -1
r_dynamic 1
r_maxdlights $maxInt
r_worldlights $maxInt
r_lightaverage 1
r_lightcache_num_entities $maxInt
r_projectedtexture_filter $minFloat
r_shadows 1
r_shadowrendertotexture 1
r_shadowmaxrendered $maxInt
r_shadow_deferred_downsample 0
r_shadow_realtime_world_debug 0
r_shadow_fallow_distance $maxInt
r_flashlightdepthtexture 1
r_flashlightrenderworld 1
r_flashlightmodelsystem 1
r_flashlightculldistant 0
r_flashlightfar $maxInt
r_flashlightfov 179.9
mat_specular 1
mat_phong 1
mat_envmapsize 1024
mat_envmaptgasize 1024
mat_envmapcomputefn 1
mat_bumpmap 1
mat_parallaxmap 1

// === ИСПРАВЛЕННЫЕ НАСТРОЙКИ СВЕТА И ЭКСПОЗИЦИИ HDR ===
mat_hdr_level 2
mat_bloomscale 1.5
mat_force_bloom 1

mat_bloom_scalefactor_scalar 4
r_bloomtintr 1
r_bloomtintg 1
r_bloomtintb 1
r_bloomtintgamma 2.2
mat_tonemap_algorithm 1
mat_force_tonemap_min_max 1
mat_exposure_override 1
mat_postprocess_x 32
mat_postprocess_y 32
mat_colorcorrection 1
r_lod 0
r_rootlod 0
r_staticprop_lod 0
lod_TransitionDist $maxInt
r_drawallrenderables 1
r_occlusion 0
r_entityclips 0
r_drawstaticprops 1
r_subdiv_force 1
r_dopixelvisibility 1
mat_picmip -10
mat_antialias 8
mat_forceaniso 16
mat_filtertextures 1
mat_filterlightmaps 1
r_radiosity 4
r_ambientboost 1
r_ambientfactor 20
r_ambientmin 1.0
r_jiggle_bones_framerate_cutoff 0

// === ИСПРАВЛЕННЫЕ КОМАНДЫ ФИЗИКИ JIGGLE BONES ===
cl_jiggle_bone_sanity 1
cl_jiggle_bone_invert 0

r_flex_smooth 1
cl_phys_props_enable 1
cl_phys_props_max $maxInt
g_ragdoll_fadespeed 0
g_ragdoll_lvfadespeed 0
cl_phys_maxticks 0
r_raindensity 1
r_rainalbedo 1
r_rainspeed 1
r_rainradius $maxInt
r_ropetranslucent 1
r_drawropes 1
rope_subdiv 8
rope_wind_dist $maxInt
rope_smooth 1
rope_averagelight 1
rope_collide 1
cl_burninggibs 1
cl_ragdoll_collide 1
r_drawmodeldecals 1
r_maxmodeldecal $maxInt
r_queued_decals 1
r_decal_cullsize 0
r_decals $maxInt
mp_decals $maxInt
r_drawbatchdecals 1
cl_detaildist $maxInt
r_propsmaxdist $maxInt
cl_detailfx_enable 1
r_renderoverlayfragment 1
r_drawdetailprops 1
cl_detailfade 0
r_drawviewmodel 1
r_drawopaqueworld 1
r_drawtranslucentworld 1
r_drawopaquerenderables 1
r_drawtranslucentrenderables 1
r_3dsky 1
r_skybox 1
r_DrawSpecificStaticProp -1
r_lightinterp 0
r_lightstyle -1
r_nosw 0
r_drawtracers_firstperson 1
r_minnewsamples 64
mat_disable_bloom 0
mat_depthfeather_enable 1
mat_software_aa_quality 1
mat_software_aa_strength 1
mat_software_aa_edge_threshold 1
mat_software_aa_blur_one_pixel_lines 1
mat_debug_post_processing_effects 0
mat_diffuse 1
mat_fastnobump 0
mat_fastspecular 0
mat_framebuffercopyobjects 1
mat_motion_blur_enabled 1
mat_motion_blur_falling_intensity 1.0
mat_motion_blur_falling_max 20.0
mat_motion_blur_falling_min 10.0
mat_motion_blur_forward_enabled 1
mat_motion_blur_percent_of_screen_max 4.0
mat_motion_blur_rotation_intensity 1.0
mat_motion_blur_strength 1.5
mat_mipmaptextures 1
mat_slopescaledepthbias_shadowmap 2.0
sfm_shadow_map_bias 0.0001
r_waterforceexpensive 1
r_waterforcereflectentities 1
r_waterdrawreflection 1
r_waterdrawrefraction 1
r_forcewaterleaf 1
mat_reflect_textures 1
mat_clipz 0
r_cheapwaterstart $maxInt
r_cheapwaterend $maxInt
cl_particle_retire_cost 0
r_particle_sim_multiplier 4
cl_particle_batch_mode 2
r_particle_subdiv_all 1
cl_show_splashes 1
cl_ejectbrass 1
r_drawflecks 1
r_drawshatter_effects 1
r_interactive_particle_res 1024
cl_new_impact_effects 1
r_updaterefracttexture 1
r_visualizeprojectedtextures 0
r_eyegloss 1
r_eyemove 1
r_eyeshift_x 0
r_eyeshift_y 0
r_eyeshift_z 0
r_eyesize 0
cl_forcepreload 1
r_threaded_particles 1
r_threaded_shadow_clip 1
r_queued_ropes 1
r_queued_post_processing 1
cl_threaded_bone_setup 1
studio_queue_mode 1
sfm_ssao_secondary_res 0
sfm_progressive_config_enabled 1
sfm_subpixel_ao 1
mod_load_anims_async 1
mod_load_mesh_async 1
mod_load_vcollide_async 1
ai_expression_optimization 0
r_threaded_renderables 1
cl_threaded_client_leaf_system 1
sv_parallel_sendsnapshot 1
mod_forcedata 1
cl_interp 0
cl_interp_ratio 1
cl_cmdrate 100
cl_updaterate 100
rate 1048576
net_splitpacket_maxrate 1048576
net_queued_packet_thread 1
r_drawlights 0
r_drawrenderboxes 0
r_drawportals 0
r_drawvisclusters 0
mat_managedtextures 1
mat_texture_list_all 1
mat_showlightmap_data 0
r_unload_models 0
r_unload_textures 0
r_lockpvs 0
dsp_off 0
dsp_enhance_stereo 1
dsp_slow_cpu 0
dsp_spatial 61
dsp_room 1
dsp_water 1
dsp_facing_away 30
dsp_volume 1.0
dsp_dist_max $maxInt
dsp_dist_min 100
dsp_db_mixback 4
dsp_db_headphone 4
dsp_mix_min 0.1
dsp_mix_max 0.8
snd_hwcompat 0
windows_speaker_config 1
snd_surround_speakers 0
snd_front_headphone_position 45.0
snd_rear_headphone_position 135.0
snd_side_headphone_position 90.0
snd_legacy_surround 0
snd_pitchquality 1
snd_spatialize_roundrobin 0
snd_no_cull 1
snd_defer_trace 0
snd_obscured_gain_dB -10
snd_mix_async 1
snd_async_fullyasync 1
snd_async_minsize 0
snd_async_max_avoid_size 26214400
snd_mixahead 0.04
snd_noextraupdate 0
sound_mix_vol 1.0
snd_duckerthreshold 0.0
snd_ducktoptovolume 1.0
snd_pitch_types 1
snd_gain 1.0
snd_gain_max 1.0
snd_prefetch_common 1
snd_headphone_pan_exponent 2.0
snd_headphone_pan_radial_weight 1.0
snd_mute_losefocus 0
snd_max_same_sounds $maxInt
snd_max_same_weapon_sounds $maxInt
snd_soundmixer "Default_Mix"
snd_async_spew_blocking 0
snd_digital_surround 1
snd_music_volume_factor 1.0
exec autoexec.cfg
host_writeconfig
"@

# Записываем видео-конфиг с твоим 32K разрешением
$videoContent = @"
"VideoConfig"
{
	"setting.cpu_level"		"3"
	"setting.gpu_level"		"3"
	"setting.mat_antialias"		"8"
	"setting.mat_aaquality"		"0"
	"setting.mat_forceaniso"		"16"
	"setting.mat_vsync"		"0"
	"setting.mat_triplebuffered"		"0"
	"setting.mat_grain_scale_override"		"0"
	"setting.gpu_mem_level"		"3"
	"setting.mem_level"		"3"
	"setting.mat_queue_mode"		"2"
	"setting.defaultres"		"32768"
	"setting.defaultresheight"		"32768"
	"setting.fullscreen"		"0"
	"setting.aspectratiomode"		"0"
	"setting.nowindowborder"		"0"
}
"@

try {
    Set-Content -Path $autoexecPath -Value $autoexecContent -Encoding UTF8
    Set-Content -Path $configPath -Value $configContent -Encoding UTF8
    Set-Content -Path $videoPath -Value $videoContent -Encoding UTF8
    Write-Log "Configurations written successfully." "SUCCESS"
} catch {
    Write-Log "Failed to write config files: $_" "ERROR"
}

# --- STEP 7: AUTOEXEC INTEGRITY CHECK ---
if (Test-Path $configPath) {
    $currentCfg = Get-Content $configPath
    $hasExec = $false
    $hasConsole = $false
    
    foreach ($line in $currentCfg) {
        if ($line -match "exec autoexec.cfg") { $hasExec = $true }
        if ($line -match "con_enable") { $hasConsole = $true }
    }
    
    if (-not $hasExec -or -not $hasConsole) {
        Disable-ReadOnly $configPath
        if (-not $hasConsole) {
            Add-Content -Path $configPath -Value 'con_enable "1"'
            Add-Content -Path $configPath -Value 'developer "1"'
        }
        if (-not $hasExec) {
            Add-Content -Path $configPath -Value "exec autoexec.cfg"
        }
    }
}

# --- STEP 8: REGISTRY LAUNCH OPTIONS AUTOMATION WITH ALL PARAMETERS ---
Write-Log "Injecting your full set of custom parameters into registry..." "INFO"

# Полная рабочая строка параметров запуска через запятую под твой жесткий максимум
$targetLaunchOptions = "-sfm_resolution 32768, -w 32768, -h 32768, -sfm_shadowmapres 29953, -notexturestreaming, -max_vram 34359738368, -num_edicts 524288, -heapsize 31457279, -threads 16, -dxlevel 95, -mat_antialias 32, -mat_forceaniso 16"

try {
    # Путь к приложению SFM в реестре Steam
    $registryPath = "HKCU:\Software\Valve\Steam\Apps\1840"
    if (-not (Test-Path $registryPath)) {
        New-Item -Path $registryPath -Force | Out-Null
    }
    
    Set-ItemProperty -Path $registryPath -Name "LaunchOptions" -Value $targetLaunchOptions -Force
    Write-Log "Launch options successfully written to Windows Registry (App ID 1840)" "SUCCESS"
    Write-Log "Injected parameters: $targetLaunchOptions" "INFO"
} catch {
    Write-Log "Could not write to Registry LaunchOptions directly: $_" "WARNING"
}

# --- STEP 8.5: BYPASS STEAM TRUNCATION (BAT-LAUNCHER CREATION) ---
# Для гарантии, что Steam не срежет параметры, создаем защищенный .bat файл прямо в папке SFM,
# который форсирует запуск SFM со ВСЕМИ твоими сверх-настройками.
$batPath = Join-Path $sfmPath "LAUNCH_HYPER_SFM.bat"
Disable-ReadOnly $batPath

$batContent = @"
@echo off
title SFM HYPER LAUNCHER (BYPASS COMPRESSION)
echo Launching SFM with ultimate maximum settings...
start "" "%~dp0sfm.exe" $targetLaunchOptions
exit
"@

try {
    Set-Content -Path $batPath -Value $batContent -Encoding Ascii
    Write-Log "Bypass BAT-Launcher successfully created: $batPath" "SUCCESS"
} catch {
    Write-Log "Failed to create BAT launcher: $_" "WARNING"
}

# --- STEP 9: READ-ONLY LOCKDOWN ---
Enable-ReadOnly $autoexecPath
Enable-ReadOnly $configPath
Enable-ReadOnly $videoPath
Enable-ReadOnly $batPath
Write-Log "All configuration files and launchers locked to Read-Only mode." "SUCCESS"

# --- STEP 10: WRITE FINAL LOG FILE ---
Write-Log "SFM Engine limits configured to your maximum!" "SUCCESS"
Write-Log "Log file saved successfully to: $logPath" "SUCCESS"

Set-Content -Path $logPath -Value ($logContent -join "`r`n")
Write-Host "--------------------------------------------------" -ForegroundColor Cyan
Write-Host "Optimization Completed! Use 'LAUNCH_HYPER_SFM.bat' in your SFM folder for a guaranteed full-throttle launch." -ForegroundColor Green