VERSION 1.0
DESCRIPTION SERVER_OPTIONS
{
    "sv_cheats"
    {
        "#Valve_Cheats"
        { BOOL }
        { "1" }
    }
    "mat_picmip"
    {
        "#Valve_Texture_Detail"
        { NUMBER -10 4 }
        { "-10" }
    }
}